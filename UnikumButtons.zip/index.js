//chrome.storage.largeSync.clear();
let stylei = document.createElement("style");
chrome.storage.sync.get("c", function (data) {
  let btnColor;
  let txtColor;
  if (data.c == null) {
    chrome.storage.sync.set({ c: ["10, 104, 244", "#ffffff"] });
    btnColor = "10, 104, 244";
    txtColor = "#ffffff";
  } else {
    btnColor = data.c[0];
    txtColor = data.c[1];
  }
  stylei.innerHTML =
    ".customizerBtnStyle {" +
    "  align-items: center;" +
    "  background-color: rgb(" +
    btnColor +
    ");" +
    "  border-radius: 10px;" +
    "  border-width: 0px;" +
    "  box-sizing: border-box;" +
    "  color: " +
    txtColor +
    ";" +
    "  cursor: pointer;" +
    "  display: inline-flex;" +
    '  font-family: -apple-system, system-ui, system-ui, "Segoe UI", Roboto, "Helvetica Neue", "Fira Sans", Ubuntu, Oxygen, "Oxygen Sans", Cantarell, "Droid Sans", "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Lucida Grande", Helvetica, Arial, sans-serif;' +
    "  font-size: 18px;" +
    "  font-weight: 600;" +
    "  justify-content: center;" +
    "  overflow: hidden;" +
    "  padding: 3px;" +
    "  padding-left: 12px;" +
    "  padding-right: 12px;" +
    "  text-align: center;" +
    "  touch-action: manipulation;" +
    "  transition: background-color 0.167s cubic-bezier(0.4, 0, 0.2, 1) 0s, color 0.167s cubic-bezier(0.4, 0, 0.2, 1) 0s, border-radius 200ms ease-in-out;" +
    "  user-select: none;" +
    "  -webkit-user-select: none;" +
    "  vertical-align: middle;" +
    "}" +
    ".customizerBtnStyle:hover" +
    "{ " +
    "  background-color: rgba(" +
    btnColor +
    ", 0.8);" +
    "  border-radius: 5px;" +
    "}" +
    ".customizerBtnStyle:active {" +
    "opacity: 0.6;" +
    "}";
});

let refi = document.querySelector("script");
refi.parentNode.insertBefore(stylei, refi);
//chrome.storage.largeSync.set({ b: buttons });
chrome.storage.largeSync.get("b", function (data) {
  if (data.b != null) {
    let canvas = document.getElementById("canvas");
    buttons = data.b;
    let div = document.createElement("DIV");
    div.style.display = "flex";
    div.style.columnGap = "3pt";
    div.style.margin = "3pt 3pt 0pt 3pt";
    div.style.flexWrap = "wrap";
    div.style.rowGap = "3pt";
    buttons.forEach((btn) => {
      let newBtn = document.createElement("BUTTON");
      newBtn.onclick = function () {
        window.open(btn[1], "_self");
      };
      let t = document.createTextNode(btn[0]);
      newBtn.appendChild(t);
      newBtn.classList.add("customizerBtnStyle");
      div.appendChild(newBtn);
    });
    canvas.insertBefore(div, canvas.childNodes[0]);
  }
});
