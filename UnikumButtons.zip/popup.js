let pageUrl;
getTab();

async function getTab() {
  let queryOptions = { active: true, currentWindow: true };
  tabs = await chrome.tabs.query(queryOptions);
  pageUrl = tabs[0].url;
}

document.addEventListener("DOMContentLoaded", function () {
  document.getElementById("savePage").addEventListener("click", function () {
    chrome.storage.largeSync.get("b", function (data) {
      let newData = data.b;
      if (newData == undefined) {
        newData = [[document.getElementById("pageName").value, pageUrl]];
      } else {
        newData.push([document.getElementById("pageName").value, pageUrl]);
      }
      chrome.storage.largeSync.set({ b: newData });
    });
    chrome.tabs.reload();
  });

  document.getElementById("openSettings").addEventListener("click", function () {
    chrome.tabs.create({ url: "settings.html" });
  });
});
